/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.logging.Level;
import java.util.logging.Logger;
import jakarta.servlet.http.Part;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.crypto.*;
import javax.crypto.spec.SecretKeySpec;


/**
 *
 * @author alumne
 */

@WebServlet(name = "testServlet", urlPatterns = {"/testServlet"})
@MultipartConfig(fileSizeThreshold=1024*1024*2, // 2MB 
                 maxFileSize=1024*1024*10,      // 10MB
                 maxRequestSize=1024*1024*50,   // 50MB
                 location="/")   
public class testServlet extends HttpServlet {

    private static final String SAVE_DIR = "/var/webapp/testGlassfish/upload";
    
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Connection connection = null;
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            
            Class.forName("org.apache.derby.jdbc.ClientDriver");

            // create a database connection
            connection = DriverManager.getConnection("jdbc:derby://localhost:1527/pr2;user=pr2;password=pr2");
            PreparedStatement statement;                        
            String sql;
            
            /*
            // SQL Commands to create the database can be found in file database.sql	
            // Example of database creation in Java can be found in file testJavaDB.java
             */
            
            sql = "select * from image";
            statement = connection.prepareStatement(sql);
            ResultSet rs = statement.executeQuery();
            /* Use the WHERE SQL clause to filter information from the database */

            while (rs.next()) {
                // read the result set
                out.println("<br>Id = " + rs.getInt("id"));
                out.println("Title = " + rs.getString("title"));
                out.println("Description = " + rs.getString("description"));
                out.println("Keywords = " + rs.getString("keywords"));
                out.println("Author = " + rs.getString("author"));
                out.println("Creator = " + rs.getString("creator"));
                out.println("Capture Date = " + rs.getString("capture_date"));
                out.println("Storage Date = " + rs.getString("storage_date"));
                out.println("Filename = " + rs.getString("filename"));
                out.println("Encrypted = " + rs.getString("encrypted"));
            }
        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                // connection close failed.
                System.err.println(e.getMessage());
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
                Connection connection = null;        
        PrintWriter writer = null;
        OutputStream out = null;
        InputStream filecontent = null;
        
        Part filePart;
        File fileSaveDir;
        
        String appPath, saveDir, fileName, savePath;
        String title, description, keywords, author, creator, capt_date, stor_date;
        String sql;

        int read;
        
        response.setContentType("text/html;charset=UTF-8");
        
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");

            // create a database connection
            connection = DriverManager.getConnection("jdbc:derby://localhost:1527/pr2;user=pr2;password=pr2");
            PreparedStatement statement;            
            
            writer = response.getWriter();
            
            title = request.getParameter("title");
            description =  request.getParameter("description");
            keywords = request.getParameter("keywords"); 
            author = request.getParameter("author");
            creator = request.getParameter("creator");
            capt_date  = request.getParameter("capture");

            // Check NULL values from form is missing. It may fail 
            // if the servlet is called directly from the browser, 
            // not passing through a jsp

            capt_date = capt_date.replace('-', '/');
            
            DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
            Date date = new Date();            
            stor_date = dateFormat.format(date);               
            
            // Create path components to save the file 
            // Directory inside web application under /uploadFiles
            // Images are accessible afterwards
           /* appPath = request.getServletContext().getRealPath("");
            // constructs path of the directory to save uploaded file
            saveDir = appPath + File.separator + SAVE_DIR;
            
            // creates the save directory if it does not exists
            fileSaveDir = new File(saveDir);
            if (!fileSaveDir.exists()) {
                fileSaveDir.mkdir();
            }*/

            // Get filename from the file selected by user
            // Get parameter from form
            filePart = request.getPart("file");

            // Extract filename from multi-part
            fileName = getFileName(filePart);

            // Get only the filename using Path class (after Java 1.7)
            Path p = Paths.get(fileName);
            fileName = p.getFileName().toString();
            //savePath = saveDir + File.separator + fileName;
            savePath = SAVE_DIR + File.separator + fileName;

            // Create file inside Web Application
            out = new FileOutputStream(new File(savePath));
            filecontent = filePart.getInputStream();
            
            final byte[] bytes = new byte[1024];

            while ((read = filecontent.read(bytes)) != -1) {
                out.write(bytes, 0, read);
            }
            System.out.println("New file " + fileName + " created at " + SAVE_DIR + "<br>");                                       
            
            sql =  "INSERT INTO IMAGE (TITLE, DESCRIPTION, KEYWORDS, AUTHOR, CREATOR, CAPTURE_DATE, STORAGE_DATE, FILENAME, ENCRYPTED) "
                 + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            statement = connection.prepareStatement(sql);
			statement.setQueryTimeout(30);  // set timeout to 30 sec.            
            statement.setString(1, title);
            statement.setString(2, description);
            statement.setString(3, keywords);
            statement.setString(4, author);
            statement.setString(5, creator);
            statement.setString(6, capt_date);
            statement.setString(7, stor_date);
            statement.setString(8, fileName);
            statement.setInt(9, 0);
            statement.executeUpdate();
            
            encrypt(savePath);
            
            request.setAttribute("message", "Upload has been done successfully!");
            getServletContext().getRequestDispatcher("/index.jsp").forward(request, response);
            
        } catch (FileNotFoundException fne) {

            // Catch exceptions on file management
            if (writer != null) {
                writer.println("You either did not specify a file to upload or are "
                        + "trying to upload a file to a protected or nonexistent "
                        + "location.");
                writer.println("<br/> ERROR: " + fne.getMessage());
            }
        } catch (ClassNotFoundException | SQLException e)
        {
            // Catch exceptions on file management
            if (writer != null) {
                writer.println("Problems with database connection ");
                writer.println("<br/> ERROR: " + e.getMessage());
            }                       
        }
        finally {

            // Close opened files
            if (out != null) {
                out.close();
            }
            if (filecontent != null) {
                filecontent.close();
            }
            if (writer != null) {
                writer.close();
            }
            
            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                // connection close failed.
                System.err.println(e.getMessage());
            }                
        }
    }

    private String getFileName(Part part) {                 
        String contentDisp = part.getHeader("content-disposition");
        String[] items = contentDisp.split(";");
        for (String s : items) {
            if (s.trim().startsWith("filename")) {
                return s.substring(s.indexOf("=") + 2, s.length()-1);
            }
        }
        return "";
    }
    
    private Boolean encrypt (String path)
    {
        byte [] keyBytes = "1234567890ABCDEF".getBytes();
        byte [] message, encryptedMessage = "Hola que tal".getBytes(), decryptedMessage;
        
        try{
            Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
            SecretKey secretKey = new SecretKeySpec(keyBytes, "AES");
            cipher.init(Cipher.ENCRYPT_MODE, secretKey);
            
            message = cipher.doFinal(encryptedMessage);
            
            System.out.println (message);
            
            cipher.init(Cipher.DECRYPT_MODE, secretKey);
            
            decryptedMessage = cipher.doFinal(message);
            
            System.out.println (decryptedMessage.toString());
            return true;
            
        }catch (Exception e) {
            System.out.println ("exception ocurred" + e.getMessage());
        }
        
        return false;    
    }
    
    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
